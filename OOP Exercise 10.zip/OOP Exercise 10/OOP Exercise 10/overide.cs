﻿namespace OOP_Exercise_10
{
    internal class overide
    {
    }
}